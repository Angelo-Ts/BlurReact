"use strict";
(() => {
  // src/shared.ts
  var STORAGE_KEY = "blurreact.v1";
  var defaults = { effect: "blur", intensity: 12, scope: "page", debug: false };
  var effects = { blur: "Blur", strong: "Strong Blur", pixel: "Pixel", blackout: "Oscura", hide: "Nascondi" };
  function emptyStore() {
    return { version: 1, rules: [], settings: { ...defaults } };
  }
  function amount(n) {
    return Math.min(40, Math.max(1, Math.round(n)));
  }
  function readStore(raw) {
    if (raw === void 0) return emptyStore();
    const value = raw;
    const identity = (x) => x && /^[a-z][a-z0-9-]*$/i.test(x.tag) && x.attrs && Object.values(x.attrs).every((a) => typeof a === "string") && Array.isArray(x.classes) && x.classes.every((c) => typeof c === "string") && typeof x.path === "string" && typeof x.parent === "string" && typeof x.structure === "string" && typeof x.textHash === "string";
    if (!value || value.version !== 1 || !Array.isArray(value.rules) || !value.settings || !(value.settings.effect in effects) || !Number.isFinite(value.settings.intensity) || !["page", "site"].includes(value.settings.scope) || !value.rules.every((r) => r && /^[a-f0-9-]{36}$/.test(r.id) && typeof r.origin === "string" && typeof r.path === "string" && ["page", "site"].includes(r.scope) && r.effect in effects && Number.isFinite(r.intensity) && r.target && Array.isArray(r.target.hosts) && r.target.hosts.every(identity) && identity(r.target.element))) {
      throw new Error("Formato delle regole non supportato. I dati sono stati conservati.");
    }
    return value;
  }

  // src/background.ts
  var queue = Promise.resolve();
  async function load() {
    return readStore((await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY]);
  }
  function validateRule(rule) {
    if (!rule || !/^[a-f0-9-]{36}$/.test(rule.id) || !(rule.effect in effects) || !Number.isFinite(rule.intensity) || !["page", "site"].includes(rule.scope) || !rule.target?.element?.tag || !Array.isArray(rule.target.hosts) || !/^https?:\/\//.test(rule.origin) || typeof rule.path !== "string") throw new Error("Regola non valida");
  }
  async function handle(message, sender) {
    if (message.type === "CONTROL") {
      const extensionPage = sender.url?.startsWith(chrome.runtime.getURL(""));
      if (!extensionPage && message.action !== "STOP") throw new Error("Comando riservato al popup");
      const tabId = extensionPage ? message.tabId : sender.tab?.id;
      if (tabId === void 0) throw new Error("Scheda non disponibile");
      await chrome.tabs.sendMessage(tabId, { type: "FRAME_CONTROL", action: message.action, settings: message.settings });
      return;
    }
    const store = await load();
    switch (message.type) {
      case "GET":
        return store;
      case "ADD": {
        validateRule(message.rule);
        const r = message.rule;
        const existing = store.rules.findIndex((x) => x.id === r.id);
        const rule = { ...r, intensity: amount(r.intensity) };
        if (existing >= 0) store.rules[existing] = rule;
        else store.rules.push(rule);
        break;
      }
      case "REMOVE":
        store.rules = store.rules.filter((r) => !message.ids.includes(r.id));
        break;
      case "UPDATE":
        if (!(message.effect in effects) || !Number.isFinite(message.intensity)) throw new Error("Effetto non valido");
        store.rules = store.rules.map((r) => message.ids.includes(r.id) ? { ...r, effect: message.effect, intensity: amount(message.intensity) } : r);
        break;
      case "SETTINGS":
        if (!(message.settings.effect in effects) || !Number.isFinite(message.settings.intensity) || !["site", "page"].includes(message.settings.scope)) throw new Error("Impostazioni non valide");
        store.settings = { ...message.settings, intensity: amount(message.settings.intensity) };
        break;
      default:
        throw new Error("Comando sconosciuto");
    }
    await chrome.storage.local.set({ [STORAGE_KEY]: store });
    return store;
  }
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id || ["FRAME_CONTROL", "NAVIGATION"].includes(message?.type)) return;
    const task = queue.then(() => handle(message, sender));
    queue = task.catch(() => void 0);
    task.then((store) => reply({ ok: true, store }), (error) => reply({ ok: false, error: String(error.message || error) }));
    return true;
  });
  function navigation(details) {
    chrome.tabs.sendMessage(details.tabId, { type: "NAVIGATION" }, { frameId: details.frameId }).catch(() => {
    });
  }
  chrome.webNavigation.onHistoryStateUpdated.addListener(navigation);
  chrome.webNavigation.onReferenceFragmentUpdated.addListener(navigation);
})();
//# sourceMappingURL=background.js.map

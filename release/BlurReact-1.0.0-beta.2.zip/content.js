"use strict";
(() => {
  // src/shared.ts
  var STORAGE_KEY = "blurreact.v1";
  var MARK = "data-blurreact";
  var OWN = "data-blurreact-ui";
  var defaults = { effect: "blur", intensity: 12, scope: "page", debug: false };
  var effects = { blur: "Blur", strong: "Strong Blur", pixel: "Pixel", blackout: "Oscura", hide: "Nascondi" };
  function emptyStore() {
    return { version: 1, enabled: true, rules: [], settings: { ...defaults } };
  }
  function pagePath(url) {
    return url.pathname + url.search + url.hash;
  }
  function applies(rule, url) {
    return rule.origin === url.origin && (rule.scope === "site" || rule.path === pagePath(url));
  }
  function amount(n) {
    return Math.min(40, Math.max(1, Math.round(n)));
  }
  async function request(message) {
    const response = await chrome.runtime.sendMessage(message);
    if (!response?.ok) throw new Error(response?.error || "Estensione non disponibile. Ricarica la pagina.");
    return response.store;
  }
  function readStore(raw) {
    if (raw === void 0) return emptyStore();
    const value = raw;
    const identity = (x) => x && /^[a-z][a-z0-9-]*$/i.test(x.tag) && x.attrs && Object.values(x.attrs).every((a) => typeof a === "string") && Array.isArray(x.classes) && x.classes.every((c) => typeof c === "string") && typeof x.path === "string" && typeof x.parent === "string" && typeof x.structure === "string" && typeof x.textHash === "string";
    if (!value || value.version !== 1 || !Array.isArray(value.rules) || !value.settings || value.enabled !== void 0 && typeof value.enabled !== "boolean" || !(value.settings.effect in effects) || !Number.isFinite(value.settings.intensity) || !["page", "site"].includes(value.settings.scope) || !value.rules.every((r) => r && /^[a-f0-9-]{36}$/.test(r.id) && typeof r.origin === "string" && typeof r.path === "string" && ["page", "site"].includes(r.scope) && r.effect in effects && Number.isFinite(r.intensity) && r.target && Array.isArray(r.target.hosts) && r.target.hosts.every(identity) && identity(r.target.element))) {
      throw new Error("Formato delle regole non supportato. I dati sono stati conservati.");
    }
    return { ...value, enabled: typeof value.enabled === "boolean" ? value.enabled : true };
  }

  // src/content/overrides.ts
  var StyleOverrides = class {
    previous = /* @__PURE__ */ new Map();
    sync(desired) {
      for (const [element, properties] of this.previous) {
        for (const [property, saved] of properties) {
          if (desired.get(element)?.has(property)) continue;
          if (element.style.getPropertyValue(property) === saved.applied && element.style.getPropertyPriority(property) === "important") {
            if (saved.value) element.style.setProperty(property, saved.value, saved.priority);
            else element.style.removeProperty(property);
          }
          properties.delete(property);
        }
        if (!properties.size) this.previous.delete(element);
      }
      for (const [candidate, desiredProperties] of desired) {
        if (!(candidate instanceof HTMLElement || candidate instanceof SVGElement)) continue;
        const element = candidate;
        for (const [property, wanted] of desiredProperties) {
          let saved = this.previous.get(element)?.get(property);
          const current = element.style.getPropertyValue(property);
          const priority = element.style.getPropertyPriority(property);
          if (saved && (current !== saved.applied || priority !== "important")) {
            saved.value = current;
            saved.priority = priority;
          }
          if (!saved && getComputedStyle(element).getPropertyValue(property) === wanted) continue;
          if (!saved) {
            saved = { value: current, priority, applied: wanted };
            if (!this.previous.has(element)) this.previous.set(element, /* @__PURE__ */ new Map());
            this.previous.get(element).set(property, saved);
          }
          saved.applied = wanted;
          if (current !== wanted || priority !== "important") element.style.setProperty(property, wanted, "important");
        }
      }
    }
  };

  // src/content/effects.ts
  var NS = "http://www.w3.org/2000/svg";
  var Effects = class {
    constructor(prefix) {
      this.prefix = prefix;
    }
    roots = /* @__PURE__ */ new Map();
    applied = /* @__PURE__ */ new Map();
    signatures = /* @__PURE__ */ new Map();
    overrides = new StyleOverrides();
    ensure(root) {
      let entry = this.roots.get(root);
      const parent = root instanceof Document ? root.documentElement : root;
      if (!parent) return;
      if (!entry) {
        const style = document.createElement("style");
        style.setAttribute(OWN, "");
        const svg = document.createElementNS(NS, "svg");
        svg.setAttribute(OWN, "");
        svg.setAttribute("width", "0");
        svg.setAttribute("height", "0");
        svg.style.cssText = "position:absolute!important;width:0!important;height:0!important;pointer-events:none!important;";
        entry = { style, svg };
        this.roots.set(root, entry);
      }
      if (!entry.style.isConnected) parent.append(entry.style);
      if (!entry.svg.isConnected) parent.append(entry.svg);
      return entry;
    }
    filter(svg, id, rule) {
      const filter = document.createElementNS(NS, "filter");
      filter.id = id;
      filter.setAttribute("x", "0");
      filter.setAttribute("y", "0");
      filter.setAttribute("width", "100%");
      filter.setAttribute("height", "100%");
      filter.setAttribute("color-interpolation-filters", "sRGB");
      const primitive = (name, attributes) => {
        const child = document.createElementNS(NS, name);
        for (const [k, v] of Object.entries(attributes)) child.setAttribute(k, v);
        filter.append(child);
      };
      if (rule.effect === "blackout") primitive("feFlood", { "flood-color": "#111827", "flood-opacity": "1" });
      else {
        const size = amount(rule.intensity);
        const half = Math.floor(size / 2);
        primitive("feFlood", { x: String(half), y: String(half), width: "1", height: "1", "flood-color": "#fff" });
        primitive("feComposite", { in2: "SourceGraphic", operator: "in", x: "0", y: "0", width: String(size), height: String(size) });
        primitive("feTile", { x: "0", y: "0", width: "100%", height: "100%", result: "grid" });
        primitive("feComposite", { in: "SourceGraphic", in2: "grid", operator: "in" });
        primitive("feMorphology", { operator: "dilate", radius: String(Math.max(1, half)) });
      }
      svg.append(filter);
    }
    render(rules, bindings) {
      for (const [id, old] of this.applied) {
        if (bindings.get(id) !== old) this.unmark(old, id);
      }
      this.applied = new Map(bindings);
      const groups = /* @__PURE__ */ new Map();
      for (const rule of rules) {
        const element = bindings.get(rule.id);
        if (!element) continue;
        const tokens = new Set((element.getAttribute(MARK) || "").split(" ").filter(Boolean));
        if (!tokens.has(rule.id)) {
          tokens.add(rule.id);
          element.setAttribute(MARK, [...tokens].join(" "));
        }
        const root = element.getRootNode();
        if (!groups.has(root)) groups.set(root, []);
        groups.get(root).push(rule);
      }
      for (const root of /* @__PURE__ */ new Set([...groups.keys(), ...this.roots.keys()])) {
        if (root instanceof ShadowRoot && !root.host.isConnected) {
          this.roots.delete(root);
          this.signatures.delete(root);
          continue;
        }
        const entry = this.ensure(root);
        if (!entry) continue;
        const list = groups.get(root) || [];
        const signature = JSON.stringify(list.map((r) => [r.id, r.effect, r.intensity]));
        if (this.signatures.get(root) === signature && entry.style.textContent) continue;
        this.signatures.set(root, signature);
        entry.svg.replaceChildren();
        entry.style.textContent = list.map((rule) => {
          const selector = `[${MARK}~="${rule.id}"]`;
          const filterId = `${this.prefix}-${rule.id}`;
          let declaration;
          switch (rule.effect) {
            case "blur":
              declaration = `filter:blur(${amount(rule.intensity)}px)!important;`;
              break;
            case "strong":
              declaration = `filter:blur(${amount(rule.intensity) * 2.5}px)!important;`;
              break;
            case "hide":
              return `${selector},${selector} *{visibility:hidden!important;}${selector},${selector}[data-blurreact-contents] > *{opacity:0!important;}`;
            default:
              this.filter(entry.svg, filterId, rule);
              declaration = `filter:url("#${filterId}")!important;`;
          }
          return `${selector}{${declaration}}${selector}[data-blurreact-contents] > *{${declaration}}`;
        }).join("\n");
      }
      for (const element of bindings.values()) {
        const contents = getComputedStyle(element).display === "contents";
        if (contents && !element.hasAttribute("data-blurreact-contents")) element.setAttribute("data-blurreact-contents", "");
        if (!contents && element.hasAttribute("data-blurreact-contents")) element.removeAttribute("data-blurreact-contents");
      }
      const desired = /* @__PURE__ */ new Map();
      const want = (element, property, value) => {
        if (!desired.has(element)) desired.set(element, /* @__PURE__ */ new Map());
        desired.get(element).set(property, value);
      };
      for (const rule of rules) {
        const element = bindings.get(rule.id);
        if (!element) continue;
        const targets = element.hasAttribute("data-blurreact-contents") ? [element, ...element.children] : [element];
        if (rule.effect === "hide") {
          for (const child of [element, ...element.querySelectorAll("*")]) want(child, "visibility", "hidden");
          for (const target of targets) want(target, "opacity", "0");
        } else {
          const filter = rule.effect === "blur" ? `blur(${amount(rule.intensity)}px)` : rule.effect === "strong" ? `blur(${amount(rule.intensity) * 2.5}px)` : `url("#${this.prefix}-${rule.id}")`;
          for (const target of targets) want(target, "filter", filter);
        }
      }
      this.overrides.sync(desired);
    }
    unmark(element, id) {
      const tokens = (element.getAttribute(MARK) || "").split(" ").filter((t) => t && t !== id);
      if (tokens.length) element.setAttribute(MARK, tokens.join(" "));
      else {
        element.removeAttribute(MARK);
        element.removeAttribute("data-blurreact-contents");
      }
    }
  };

  // src/content/identity.ts
  var stableNames = ["id", "data-testid", "data-test", "data-qa", "data-id", "name", "aria-label", "role", "type", "alt"];
  var strongNames = ["id", "data-testid", "data-test", "data-qa", "data-id"];
  var isOwned = (element) => element.hasAttribute(OWN) || !!element.closest(`[${OWN}]`);
  function hash(text) {
    let n = 2166136261;
    for (const char of text) n = Math.imul(n ^ char.charCodeAt(0), 16777619);
    return (n >>> 0).toString(36);
  }
  function stable(value) {
    return value.length < 160 && !/^(:r|:R|_r_|radix-|react-aria)/.test(value) && !/[a-f0-9]{12,}/i.test(value);
  }
  function attrs(element) {
    return Object.fromEntries(stableNames.flatMap((name) => {
      const value = element.getAttribute(name);
      return value && stable(value) ? [[name, value]] : [];
    }));
  }
  function attributeSelector(tag, name, value) {
    return `${tag}[${CSS.escape(name)}="${CSS.escape(value)}"]`;
  }
  function path(element) {
    const parts = [];
    let node = element;
    while (node) {
      const a = attrs(node);
      const key = strongNames.find((k) => a[k]);
      if (key) {
        parts.unshift(attributeSelector(node.localName, key, a[key]));
        break;
      }
      let part = node.localName;
      if (node.parentElement) {
        const siblings = [...node.parentElement.children].filter((s) => s.localName === node.localName);
        part += `:nth-of-type(${siblings.indexOf(node) + 1})`;
      }
      parts.unshift(part);
      node = node.parentElement;
    }
    return parts.join(" > ");
  }
  function identify(element) {
    const attributes = attrs(element);
    const tag = element.localName;
    return {
      tag,
      attrs: attributes,
      classes: [...element.classList].filter((c) => stable(c) && !/^(css-|sc-|jsx-)/.test(c)).slice(0, 6),
      path: path(element),
      parent: element.parentElement ? path(element.parentElement) : "",
      structure: [...element.children].filter((e) => !isOwned(e)).map((e) => e.localName).slice(0, 30).join(","),
      // Never persist form values or plaintext from the page.
      textHash: hash((element.textContent || "").trim().replace(/\s+/g, " ").slice(0, 500)),
      selectors: Object.entries(attributes).map(([k, v]) => attributeSelector(tag, k, v))
    };
  }
  function targetFor(element) {
    const hosts = [];
    let root = element.getRootNode();
    while (root instanceof ShadowRoot) {
      hosts.unshift(identify(root.host));
      root = root.host.getRootNode();
    }
    return { hosts, element: identify(element) };
  }
  function compatible(identity, candidate) {
    return candidate.localName === identity.tag && !isOwned(candidate) && strongNames.every((name) => !identity.attrs[name] || candidate.getAttribute(name) === identity.attrs[name]);
  }
  function candidates(identity, root) {
    const key = strongNames.find((name) => identity.attrs[name]);
    const selector = key ? attributeSelector(identity.tag, key, identity.attrs[key]) : identity.tag;
    return [...root.querySelectorAll(selector)].filter((e) => compatible(identity, e));
  }
  function score(identity, candidate) {
    if (!compatible(identity, candidate)) return -1e3;
    const current = identify(candidate);
    let result = 10;
    for (const [key, value] of Object.entries(identity.attrs)) {
      if (current.attrs[key] === value) result += strongNames.includes(key) ? 110 : 32;
      else if (strongNames.includes(key)) return -1e3;
      else result -= 18;
    }
    if (current.parent === identity.parent) result += 25;
    if (current.path === identity.path) result += 15;
    if (current.structure === identity.structure) result += 12;
    if (identity.textHash !== hash("") && current.textHash === identity.textHash) result += 24;
    result += identity.classes.filter((c) => current.classes.includes(c)).length * 7;
    return result;
  }
  function match(identity, candidates2) {
    const ranked = [...candidates2].filter((e) => e.isConnected).map((element) => ({ element, score: score(identity, element) })).sort((a, b) => b.score - a.score);
    const best = ranked[0];
    const ambiguous = !!best && !!ranked[1] && best.score - ranked[1].score < 20;
    return { element: best && best.score >= 62 && !ambiguous ? best.element : void 0, confidence: best?.score || 0, ambiguous };
  }
  function resolveRoot(target) {
    let root = document;
    for (const host of target.hosts) {
      const result = match(host, candidates(host, root));
      if (!result.element?.shadowRoot) return;
      root = result.element.shadowRoot;
    }
    return root;
  }

  // src/content/engine.ts
  var Engine = class {
    store;
    bindings = /* @__PURE__ */ new Map();
    status = /* @__PURE__ */ new Map();
    pools = /* @__PURE__ */ new Map();
    poolRoots = /* @__PURE__ */ new Map();
    roots = /* @__PURE__ */ new Set();
    customHosts = /* @__PURE__ */ new Set();
    dirty = /* @__PURE__ */ new Set();
    attributes = /* @__PURE__ */ new Set();
    full = true;
    timer;
    url = location.href;
    effects = new Effects(`br-${crypto.randomUUID()}`);
    observers = /* @__PURE__ */ new Map();
    onChange = () => {
    };
    get selectionRoots() {
      return [...this.roots].filter((root) => root instanceof Document || root.host.isConnected);
    }
    constructor() {
      this.observe(document);
      addEventListener("popstate", () => this.navigate());
      addEventListener("hashchange", () => this.navigate());
      addEventListener("pageshow", () => this.navigate(true));
      setInterval(() => {
        this.navigate();
        for (const host of this.customHosts) {
          if (!host.isConnected) {
            this.customHosts.delete(host);
            continue;
          }
          if (host.shadowRoot && !this.roots.has(host.shadowRoot)) {
            this.discover(host.shadowRoot);
            this.full = true;
            this.schedule();
          }
        }
      }, 700);
    }
    setStore(store) {
      this.store = store;
      this.full = true;
      this.flush();
    }
    navigate(force = false) {
      if (force || this.url !== location.href) {
        this.url = location.href;
        this.full = true;
        this.flush();
      }
    }
    observe(root) {
      if (this.roots.has(root)) return;
      this.roots.add(root);
      const observer = new MutationObserver((records) => {
        let changed = false;
        for (const record of records) {
          if (record.target instanceof Element && isOwned(record.target)) continue;
          if (record.type === "attributes" && (record.attributeName === MARK || record.attributeName === "data-blurreact-contents")) {
            if (record.target instanceof Element && !record.target.hasAttribute(MARK) && [...this.bindings.values()].includes(record.target)) changed = true;
            continue;
          }
          if (record.type === "childList") {
            const nodes = [...record.addedNodes, ...record.removedNodes];
            if (nodes.length && nodes.every((n) => n instanceof Element && n.hasAttribute(OWN))) {
              if (record.removedNodes.length) changed = true;
              continue;
            }
            for (const node of record.addedNodes) if (node instanceof Element && !isOwned(node)) {
              this.dirty.add(node);
              this.discover(node);
            }
          }
          if (record.type === "attributes" && record.target instanceof Element) this.attributes.add(record.target);
          changed = true;
        }
        if (changed) this.schedule();
      });
      observer.observe(root, { subtree: true, childList: true, attributes: true, characterData: true });
      this.observers.set(root, observer);
      this.discover(root);
    }
    discover(start) {
      const visit = (element) => {
        if (isOwned(element)) return;
        if (element.hasAttribute(MARK)) {
          const tokens = (element.getAttribute(MARK) || "").split(" ").filter((id) => this.bindings.get(id) === element);
          if (!tokens.length) element.removeAttribute(MARK);
          else if (tokens.join(" ") !== element.getAttribute(MARK)) element.setAttribute(MARK, tokens.join(" "));
        }
        if (element.localName.includes("-")) this.customHosts.add(element);
        if (element.shadowRoot) this.observe(element.shadowRoot);
      };
      if (start instanceof Element) visit(start);
      for (const node of start.querySelectorAll("*")) visit(node);
    }
    schedule() {
      if (this.timer !== void 0) return;
      this.timer = 1;
      queueMicrotask(() => {
        this.timer = void 0;
        this.flush();
      });
    }
    flush() {
      if (!this.store || !document.documentElement) return;
      if (!this.store.enabled) {
        this.bindings.clear();
        this.status.clear();
        this.effects.render([], this.bindings);
        this.onChange();
        return;
      }
      const url = new URL(location.href);
      if (url.protocol === "about:" && document.referrer) {
        try {
          url.href = document.referrer;
        } catch {
        }
      }
      const rules = this.store.rules.filter((r) => applies(r, url));
      const ids = new Set(rules.map((r) => r.id));
      for (const id of this.pools.keys()) if (!ids.has(id)) {
        this.pools.delete(id);
        this.poolRoots.delete(id);
      }
      for (const [root, observer] of this.observers) if (root instanceof ShadowRoot && !root.host.isConnected) {
        observer.disconnect();
        this.observers.delete(root);
        this.roots.delete(root);
      }
      const next = /* @__PURE__ */ new Map();
      this.status.clear();
      for (const rule of rules) {
        const root = resolveRoot(rule.target);
        if (!root) {
          this.status.set(rule.id, "In attesa del componente");
          continue;
        }
        if (!this.roots.has(root)) this.observe(root);
        let pool = this.pools.get(rule.id);
        if (this.full || !pool || this.poolRoots.get(rule.id) !== root) {
          pool = new Set(candidates(rule.target.element, root));
          this.pools.set(rule.id, pool);
          this.poolRoots.set(rule.id, root);
        } else {
          for (const node of pool) if (!node.isConnected || node.getRootNode() !== root || !compatible(rule.target.element, node)) pool.delete(node);
          for (const node of this.attributes) if (node.getRootNode() === root && compatible(rule.target.element, node)) pool.add(node);
          for (const changed of this.dirty) {
            if (!changed.isConnected || changed.getRootNode() !== root || isOwned(changed)) continue;
            if (compatible(rule.target.element, changed)) pool.add(changed);
            for (const node of candidates(rule.target.element, changed)) pool.add(node);
          }
        }
        const result = match(rule.target.element, pool);
        if (result.element) {
          next.set(rule.id, result.element);
          this.status.set(rule.id, "Applicata");
        } else this.status.set(rule.id, result.ambiguous ? "Corrispondenza ambigua" : "In attesa dell\u2019elemento");
        if (this.store.settings.debug && this.bindings.get(rule.id) !== result.element) console.debug("[BlurReact]", rule.id, this.status.get(rule.id), result.confidence);
      }
      this.bindings = next;
      this.effects.render(rules, next);
      this.full = false;
      this.dirty.clear();
      this.attributes.clear();
      this.onChange();
    }
    preview(rule, element) {
      if (!this.store) return;
      this.bindings.set(rule.id, element);
      this.effects.render([...this.store.rules.filter((r) => r.id !== rule.id), rule], this.bindings);
    }
  };

  // src/content/media-selection.ts
  var MediaSelection = class {
    constructor(layer, roots, hover, select) {
      this.layer = layer;
      this.roots = roots;
      this.hover = hover;
      this.select = select;
      this.refresh();
      this.timer = window.setInterval(() => this.refresh(), 250);
    }
    surfaces = /* @__PURE__ */ new Map();
    timer;
    refresh() {
      const media = new Set(this.roots().flatMap((root) => [...root.querySelectorAll("video[controls],audio[controls]")]));
      for (const [element, surface] of this.surfaces) if (!media.has(element) || !element.isConnected) {
        surface.remove();
        this.surfaces.delete(element);
      }
      for (const element of media) {
        if (this.surfaces.has(element) || isOwned(element)) continue;
        const surface = document.createElement("div");
        surface.dataset.mediaSelection = element.localName;
        surface.style.cssText = "all:initial;position:fixed;pointer-events:auto;cursor:crosshair;background:transparent;z-index:0;";
        const target = (event) => {
          const root = element.getRootNode();
          return root.elementsFromPoint(event.clientX, event.clientY).find((e) => !isOwned(e)) || element;
        };
        surface.addEventListener("pointermove", (event) => this.hover(target(event)));
        surface.addEventListener("pointerdown", (event) => {
          event.preventDefault();
          event.stopPropagation();
        });
        surface.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          this.select(target(event));
        });
        this.layer.prepend(surface);
        this.surfaces.set(element, surface);
      }
      this.position();
    }
    position() {
      for (const [element, surface] of this.surfaces) {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        let left = Math.max(0, rect.left), top = Math.max(0, rect.top);
        let right = Math.min(innerWidth, rect.right), bottom = Math.min(innerHeight, rect.bottom);
        let parent = element.parentElement;
        while (parent) {
          const css = getComputedStyle(parent);
          const bounds = parent.getBoundingClientRect();
          if (/(hidden|clip|scroll|auto)/.test(css.overflowX)) {
            left = Math.max(left, bounds.left);
            right = Math.min(right, bounds.right);
          }
          if (/(hidden|clip|scroll|auto)/.test(css.overflowY)) {
            top = Math.max(top, bounds.top);
            bottom = Math.min(bottom, bounds.bottom);
          }
          parent = parent.parentElement;
        }
        const visible = element.isConnected && style.visibility === "visible" && Number(style.opacity) !== 0 && right > left && bottom > top;
        surface.style.display = visible ? "block" : "none";
        if (visible) {
          surface.style.left = left + "px";
          surface.style.top = top + "px";
          surface.style.width = right - left + "px";
          surface.style.height = bottom - top + "px";
        }
      }
    }
    stop() {
      clearInterval(this.timer);
      for (const surface of this.surfaces.values()) surface.remove();
      this.surfaces.clear();
    }
  };

  // src/content/selection.ts
  var CSS_UI = `:host{all:initial!important;position:fixed!important;inset:0!important;pointer-events:none!important;z-index:2147483647!important;font:14px system-ui!important;color:#edf2ff!important;color-scheme:dark!important}*{box-sizing:border-box}#panel{pointer-events:auto;position:fixed;bottom:20px;left:50%;transform:translateX(-50%);width:min(760px,96vw);background:#121827;border:1px solid #52617e;border-radius:16px;padding:14px 18px;box-shadow:0 12px 48px #0008}header,.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}header{justify-content:space-between;margin-bottom:10px}strong{font-size:16px}p{margin:9px 0 0;color:#b8c3d9;font-size:12px}button,select{font:inherit;color:inherit;background:#25314b;border:1px solid #536384;border-radius:8px;padding:7px 10px;cursor:pointer}button:hover{background:#384c76}button.primary{background:#6468ed;border-color:#9295ff}label{display:flex;gap:7px;align-items:center;font-size:12px}input{accent-color:#9194ff;width:110px}#outline{position:fixed;border:2px solid #9b8aff;background:#9b8aff18;box-shadow:0 0 0 1px #171525;pointer-events:none;border-radius:3px}#tag{position:absolute;top:0;left:0;transform:translateY(-100%);font:12px system-ui;background:#6551c7;color:white;padding:3px 7px;white-space:nowrap}#status{min-height:16px}#status.error{color:#ff9f9f}button:disabled{opacity:.5;cursor:default}`;
  function make(tag, text) {
    const node = document.createElement(tag);
    if (text) node.textContent = text;
    return node;
  }
  var Selection = class {
    constructor(engine2) {
      this.engine = engine2;
    }
    host;
    current;
    leaf;
    outline;
    tag;
    status;
    count;
    frame = 0;
    selected = /* @__PURE__ */ new Set();
    settings;
    pending = 0;
    media;
    configure(settings) {
      if (this.host) this.settings = { ...settings };
    }
    start(settings) {
      this.stop();
      this.settings = { ...settings };
      this.selected.clear();
      const host = make("div");
      host.setAttribute(OWN, "selection");
      this.host = host;
      const shadow = host.attachShadow({ mode: "open" });
      const style = make("style");
      style.textContent = CSS_UI;
      shadow.append(style);
      const panel = make("section");
      panel.id = "panel";
      panel.setAttribute("aria-label", "BlurReact selezione multipla");
      const header = make("header");
      const title = make("strong", "BlurReact");
      this.count = make("span", "0 selezionati");
      const done = make("button", "Fine \xB7 Esc");
      done.className = "primary";
      done.onclick = () => this.finish();
      header.append(title, this.count, done);
      panel.append(header);
      const row = make("div");
      row.className = "row";
      const effect = make("select");
      effect.setAttribute("aria-label", "Effetto");
      for (const [value, label2] of Object.entries(effects)) {
        const option = make("option", label2);
        option.value = value;
        effect.append(option);
      }
      effect.value = settings.effect;
      const label = make("label", "Intensit\xE0");
      const input = make("input");
      input.type = "range";
      input.min = "1";
      input.max = "40";
      input.value = String(settings.intensity);
      input.setAttribute("aria-label", "Intensit\xE0");
      const output = make("output", input.value);
      label.append(input, output);
      const scope = make("select");
      scope.setAttribute("aria-label", "Ambito dei nuovi oscuramenti");
      for (const [value, text] of [["page", "Questa pagina"], ["site", "Tutto il sito"]]) {
        const option = make("option", text);
        option.value = value;
        scope.append(option);
      }
      scope.value = settings.scope;
      const up = make("button", "\u2191 Genitore");
      up.onclick = () => this.ancestor(true);
      const down = make("button", "\u2193 Figlio");
      down.onclick = () => this.ancestor(false);
      const apply = make("button", "Oscura selezione");
      apply.onclick = () => {
        if (this.current) void this.add(this.current);
      };
      row.append(effect, label, scope, up, down, apply);
      panel.append(row);
      effect.onchange = () => {
        this.settings.effect = effect.value;
        void this.update();
      };
      input.oninput = () => {
        this.settings.intensity = Number(input.value);
        output.value = input.value;
        void this.update();
      };
      scope.onchange = () => {
        this.settings.scope = scope.value;
        void request({ type: "SETTINGS", settings: this.settings }).catch((e) => this.message(e.message, true));
      };
      panel.append(make("p", "Clicca pi\xF9 elementi, senza tasti aggiuntivi. \u2191 e \u2193 cambiano livello. Effetto e intensit\xE0 aggiornano gli elementi scelti in questa sessione."));
      this.status = make("p", "Le regole vengono salvate automaticamente.");
      this.status.id = "status";
      this.status.setAttribute("role", "status");
      panel.append(this.status);
      this.outline = make("div");
      this.outline.id = "outline";
      this.outline.hidden = true;
      this.tag = make("span");
      this.tag.id = "tag";
      this.outline.append(this.tag);
      if (window.top !== window) panel.style.display = "none";
      panel.style.zIndex = "2";
      this.outline.style.zIndex = "1";
      shadow.append(this.outline, panel);
      document.documentElement.append(host);
      this.media = new MediaSelection(shadow, () => this.engine.selectionRoots, (element) => {
        if (element !== this.leaf) {
          this.leaf = element;
          this.current = element;
        }
      }, (element) => {
        const target = element === this.leaf ? this.current : element;
        if (target) void this.add(target);
      });
      document.addEventListener("pointermove", this.move, true);
      document.addEventListener("pointerdown", this.block, true);
      document.addEventListener("click", this.click, true);
      document.addEventListener("keydown", this.key, true);
      this.draw();
    }
    stop() {
      this.host?.remove();
      this.host = void 0;
      this.current = void 0;
      this.leaf = void 0;
      this.media?.stop();
      this.media = void 0;
      cancelAnimationFrame(this.frame);
      document.removeEventListener("pointermove", this.move, true);
      document.removeEventListener("pointerdown", this.block, true);
      document.removeEventListener("click", this.click, true);
      document.removeEventListener("keydown", this.key, true);
    }
    finish() {
      void request({ type: "CONTROL", tabId: -1, action: "STOP" }).catch(() => this.stop());
    }
    owned(event) {
      return event.composedPath().includes(this.host);
    }
    pick(event) {
      let candidate = event.composedPath().find((n) => n instanceof Element);
      if (!candidate || isOwned(candidate)) return;
      if (candidate.namespaceURI === "http://www.w3.org/2000/svg") candidate = candidate.closest("svg") || candidate;
      while (candidate.parentElement && ["strong", "em", "b", "i", "small", "path", "tspan"].includes(candidate.localName)) candidate = candidate.parentElement;
      if (["html", "body", "script", "style", "head"].includes(candidate.localName)) return;
      return candidate;
    }
    move = (event) => {
      if (this.owned(event)) return;
      const candidate = this.pick(event);
      if (candidate !== this.leaf) {
        this.leaf = candidate;
        this.current = candidate;
      }
    };
    block = (event) => {
      if (this.owned(event)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
    };
    click = (event) => {
      if (this.owned(event)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      const picked = this.pick(event);
      const target = picked === this.leaf ? this.current : picked;
      if (target) void this.add(target);
    };
    key = (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopImmediatePropagation();
        this.finish();
      }
      if (!this.owned(event) && ["ArrowUp", "ArrowDown"].includes(event.key)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        this.ancestor(event.key === "ArrowUp");
      }
    };
    ancestor(up) {
      if (!this.current) return;
      if (up) {
        const parent = this.current.parentElement;
        if (parent && !["body", "html"].includes(parent.localName)) this.current = parent;
      } else if (this.leaf && this.current !== this.leaf) {
        let next = this.leaf;
        while (next.parentElement && next.parentElement !== this.current) next = next.parentElement;
        if (next.parentElement === this.current) this.current = next;
      }
    }
    draw = () => {
      if (!this.host) return;
      this.media?.position();
      if (!this.host.isConnected && document.documentElement) document.documentElement.append(this.host);
      if (this.outline && this.current?.isConnected) {
        let rect = this.current.getBoundingClientRect();
        if (!rect.width && !rect.height && this.current.children.length) rect = this.current.children[0].getBoundingClientRect();
        this.outline.hidden = false;
        this.outline.style.cssText = `left:${rect.left}px;top:${rect.top}px;width:${rect.width}px;height:${rect.height}px;`;
        if (this.tag) this.tag.textContent = this.current.localName.toUpperCase();
      } else if (this.outline) this.outline.hidden = true;
      this.frame = requestAnimationFrame(this.draw);
    };
    message(text, error = false) {
      if (this.status) {
        this.status.textContent = text;
        this.status.className = error ? "error" : "";
      }
    }
    async add(element) {
      const existing = [...this.engine.bindings].find(([, node]) => node === element)?.[0];
      const url = new URL(location.protocol === "about:" ? document.referrer : location.href);
      const rule = { id: existing || crypto.randomUUID(), origin: url.origin, path: pagePath(url), scope: this.settings.scope, effect: this.settings.effect, intensity: this.settings.intensity, target: targetFor(element), createdAt: Date.now() };
      this.pending++;
      this.message("Salvataggio\u2026");
      this.engine.preview(rule, element);
      try {
        await request({ type: "ADD", rule });
        this.selected.add(rule.id);
        if (this.count) this.count.textContent = `${this.selected.size} selezionati`;
        this.message("Salvato. Puoi selezionare altri elementi.");
      } catch (error) {
        this.engine.flush();
        this.message(`Non salvato: ${error.message}`, true);
      } finally {
        this.pending--;
      }
    }
    async update() {
      try {
        await request({ type: "SETTINGS", settings: this.settings });
        if (this.selected.size) await request({ type: "UPDATE", ids: [...this.selected], effect: this.settings.effect, intensity: this.settings.intensity });
      } catch (error) {
        this.message(error.message, true);
      }
    }
  };

  // src/content/index.ts
  var engine = new Engine();
  var selection = new Selection(engine);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[STORAGE_KEY]) {
      try {
        const next = readStore(changes[STORAGE_KEY].newValue);
        const previous = engine.store?.settings;
        if (!previous || next.settings.effect !== previous.effect || next.settings.intensity !== previous.intensity || next.settings.scope !== previous.scope) selection.configure(next.settings);
        engine.setStore(next);
      } catch (error) {
        console.error("[BlurReact]", error);
      }
    }
  });
  chrome.storage.local.get(STORAGE_KEY).then((data) => {
    if (!engine.store) engine.setStore(readStore(data[STORAGE_KEY]));
  }).catch((error) => console.error("[BlurReact] Impossibile caricare le regole", error));
  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    if (message.type === "NAVIGATION") {
      engine.navigate();
      reply({ ok: true });
    }
    if (message.type === "FRAME_CONTROL") {
      if (message.action === "START") selection.start(message.settings || engine.store?.settings || defaults);
      else selection.stop();
      reply({ ok: true });
    }
  });
})();
//# sourceMappingURL=content.js.map

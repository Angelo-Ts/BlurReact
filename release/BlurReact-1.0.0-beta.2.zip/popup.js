"use strict";
(() => {
  // src/shared.ts
  var STORAGE_KEY = "blurreact.v1";
  var defaults = { effect: "blur", intensity: 12, scope: "page", debug: false };
  var effects = { blur: "Blur", strong: "Strong Blur", pixel: "Pixel", blackout: "Oscura", hide: "Nascondi" };
  function emptyStore() {
    return { version: 1, enabled: true, rules: [], settings: { ...defaults } };
  }
  function pagePath(url) {
    return url.pathname + url.search + url.hash;
  }
  function applies(rule, url) {
    return rule.origin === url.origin && (rule.scope === "site" || rule.path === pagePath(url));
  }
  async function request(message) {
    const response = await chrome.runtime.sendMessage(message);
    if (!response?.ok) throw new Error(response?.error || "Estensione non disponibile. Ricarica la pagina.");
    return response.store;
  }
  function readStore(raw) {
    if (raw === void 0) return emptyStore();
    const value = raw;
    const identity = (x) => x && /^[a-z][a-z0-9-]*$/i.test(x.tag) && x.attrs && Object.values(x.attrs).every((a) => typeof a === "string") && Array.isArray(x.classes) && x.classes.every((c) => typeof c === "string") && typeof x.path === "string" && typeof x.parent === "string" && typeof x.structure === "string" && typeof x.textHash === "string";
    if (!value || value.version !== 1 || !Array.isArray(value.rules) || !value.settings || value.enabled !== void 0 && typeof value.enabled !== "boolean" || !(value.settings.effect in effects) || !Number.isFinite(value.settings.intensity) || !["page", "site"].includes(value.settings.scope) || !value.rules.every((r) => r && /^[a-f0-9-]{36}$/.test(r.id) && typeof r.origin === "string" && typeof r.path === "string" && ["page", "site"].includes(r.scope) && r.effect in effects && Number.isFinite(r.intensity) && r.target && Array.isArray(r.target.hosts) && r.target.hosts.every(identity) && identity(r.target.element))) {
      throw new Error("Formato delle regole non supportato. I dati sono stati conservati.");
    }
    return { ...value, enabled: typeof value.enabled === "boolean" ? value.enabled : true };
  }

  // src/popup.ts
  var $ = (id) => document.getElementById(id);
  var tabId;
  var urls = [];
  var store;
  var effect = $("effect");
  var intensity = $("intensity");
  var scope = $("scope");
  var masterEnabled = $("master-enabled");
  function status(text, error = false) {
    $("status").textContent = text;
    $("status").className = error ? "error" : "";
  }
  function settings() {
    return { effect: effect.value, intensity: Number(intensity.value), scope: scope.value, debug: store?.settings.debug || false };
  }
  function hint() {
    const solid = ["blackout", "hide"].includes(effect.value);
    intensity.disabled = solid;
    $("effect-hint").textContent = solid ? "Copertura completa. Questo effetto non richiede intensit\xE0." : "Seleziona pi\xF9 elementi con clic consecutivi.";
    $("value").value = solid ? "\u2014" : intensity.value;
  }
  async function saveSettings() {
    hint();
    try {
      await request({ type: "SETTINGS", settings: settings() });
    } catch (e) {
      status(e.message, true);
    }
  }
  function relevant() {
    return store.rules.filter((r) => urls.some((url) => r.origin === url.origin));
  }
  function render() {
    if (document.activeElement instanceof HTMLInputElement && document.activeElement.type === "range") return;
    masterEnabled.checked = store.enabled;
    $("master-state").textContent = store.enabled ? "Tutte le regole sono applicate" : "Regole sospese, nessun dato eliminato";
    $("start").disabled = !store.enabled || !urls.some((u) => ["https:", "http:"].includes(u.protocol));
    const list = $("rules");
    list.replaceChildren();
    const rules = relevant();
    $("count").textContent = String(rules.length);
    if (!rules.length) {
      const p = document.createElement("p");
      p.className = "empty";
      p.textContent = "Nessun oscuramento salvato per questo sito.";
      list.append(p);
    }
    for (const rule of rules) {
      const row = document.createElement("article");
      row.className = "rule";
      row.dataset.ruleId = rule.id;
      const header = document.createElement("header");
      const name = document.createElement("strong");
      name.textContent = rule.target.element.tag.toUpperCase();
      const info = document.createElement("small");
      info.textContent = `${new URL(rule.origin).hostname} \xB7 ${rule.scope === "site" ? "Tutto il sito" : rule.path}`;
      header.append(name, info);
      row.append(header);
      const controls = document.createElement("div");
      controls.className = "controls";
      const select = document.createElement("select");
      select.setAttribute("aria-label", `Effetto ${name.textContent}`);
      for (const [value, text] of Object.entries(effects)) {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = text;
        select.append(option);
      }
      select.value = rule.effect;
      const range = document.createElement("input");
      range.type = "range";
      range.min = "1";
      range.max = "40";
      range.value = String(rule.intensity);
      range.setAttribute("aria-label", `Intensit\xE0 ${name.textContent}`);
      range.disabled = ["hide", "blackout"].includes(rule.effect);
      const update = async () => {
        try {
          await request({ type: "UPDATE", ids: [rule.id], effect: select.value, intensity: Number(range.value) });
          status("Modifica salvata.");
        } catch (e) {
          status(e.message, true);
        }
      };
      select.onchange = update;
      range.oninput = update;
      range.onblur = () => render();
      const remove = document.createElement("button");
      remove.textContent = "Ripristina";
      remove.onclick = () => restore([rule.id]);
      controls.append(select, range, remove);
      row.append(controls);
      list.append(row);
    }
    $("restore-page").disabled = !rules.some((r) => urls.some((u) => applies(r, u)));
    $("restore-site").disabled = !rules.length;
  }
  async function restore(ids) {
    try {
      await request({ type: "REMOVE", ids });
      status("Ripristino salvato.");
    } catch (e) {
      status(e.message, true);
    }
  }
  $("start").onclick = async () => {
    if (tabId === void 0) return;
    try {
      await request({ type: "SETTINGS", settings: settings() });
      await request({ type: "CONTROL", tabId, action: "START", settings: settings() });
      window.close();
    } catch {
      status("Pagina non accessibile. Ricarica la scheda dopo l\u2019installazione. Edge, store e PDF possono impedire l\u2019accesso.", true);
    }
  };
  $("stop").onclick = async () => {
    if (tabId === void 0) return;
    try {
      await request({ type: "CONTROL", tabId, action: "STOP" });
      status("Selezione terminata. Gli oscuramenti restano salvati.");
    } catch {
      status("Nessuna pagina accessibile.", true);
    }
  };
  effect.onchange = saveSettings;
  intensity.oninput = saveSettings;
  intensity.onblur = () => render();
  scope.onchange = saveSettings;
  masterEnabled.onchange = async () => {
    const enabled = masterEnabled.checked;
    try {
      await request({ type: "SET_ENABLED", enabled });
      status(enabled ? "Tutti gli oscuramenti sono attivi." : "Oscuramenti sospesi. Le regole sono state conservate.");
    } catch (e) {
      masterEnabled.checked = !enabled;
      status(e.message, true);
    }
  };
  $("restore-page").onclick = () => restore(relevant().filter((r) => urls.some((u) => applies(r, u))).map((r) => r.id));
  $("restore-site").onclick = () => restore(relevant().map((r) => r.id));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[STORAGE_KEY]) {
      store = readStore(changes[STORAGE_KEY].newValue);
      render();
    }
  });
  async function init() {
    try {
      store = await request({ type: "GET" });
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      tabId = tab?.id;
      if (tab?.url) urls.push(new URL(tab.url));
      if (tabId !== void 0) {
        const frames = await chrome.webNavigation.getAllFrames({ tabId });
        for (const frame of frames || []) {
          try {
            const url = new URL(frame.url);
            if (["http:", "https:"].includes(url.protocol)) urls.push(url);
          } catch {
          }
        }
      }
      $("site").textContent = urls[0]?.hostname || "Pagina non accessibile";
      const initial = store.settings || defaults;
      effect.value = initial.effect;
      intensity.value = String(initial.intensity);
      scope.value = initial.scope;
      hint();
      render();
      $("start").disabled = !store.enabled || !urls.some((u) => ["https:", "http:"].includes(u.protocol));
    } catch (e) {
      status(e.message, true);
    }
  }
  void init();
})();
//# sourceMappingURL=popup.js.map
